import React, { useContext, useMemo, useState } from 'react';
import Card from '../ui/Card.tsx';
import Select from '../ui/Select.tsx';
import { GrantApplicationsIcon, CheckCircleIcon, XCircleIcon } from '../../constants.tsx';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { ThemeContext } from '../ThemeContext.tsx';
import { useAppContext } from '../AppContext.tsx';
import Spinner from '../ui/Spinner.tsx';
import { GrantApplication } from '../../types.ts';

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <Card>
        <div className="flex items-center">
            <div className="p-3 bg-neutral-200-light dark:bg-neutral-700-dark rounded-lg mr-4 text-brand-green dark:text-brand-dark-green-text">
                {icon}
            </div>
            <div>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-sm">{title}</p>
                <p className="text-2xl font-bold text-brand-green-text dark:text-brand-dark-green-text">{value}</p>
            </div>
        </div>
    </Card>
);

const GrantAnalyticsView: React.FC = () => {
  const { theme } = useContext(ThemeContext);
  const { grantApplications, isLoadingGrantApplications, grantCategories } = useAppContext();

  const availableYears = useMemo(() => {
    if (isLoadingGrantApplications || grantApplications.length === 0) {
      return [new Date().getFullYear()];
    }
    const years = [...new Set(grantApplications.map(d => new Date(d.submission_timestamp).getFullYear()))].sort((a, b) => b - a);
    return years.length > 0 ? years : [new Date().getFullYear()];
  }, [grantApplications, isLoadingGrantApplications]);

  const [selectedYear, setSelectedYear] = useState(availableYears[0]);
  
  React.useEffect(() => {
    if (!availableYears.includes(selectedYear)) {
      setSelectedYear(availableYears[0] || new Date().getFullYear());
    }
  }, [availableYears, selectedYear]);

  const yearOptions = availableYears.map(y => ({ value: String(y), label: String(y) }));

  const yearData = useMemo(() => {
    return grantApplications.filter(d => new Date(d.submission_timestamp).getFullYear() === selectedYear);
  }, [grantApplications, selectedYear]);

  const {
    totalApplications,
    approvedCount,
    rejectedCount,
    totalRequested,
    totalApproved,
    byCategoryData,
    byStatusData,
    monthlyData
  } = useMemo(() => {
    if (yearData.length === 0) {
      return { totalApplications: 0, approvedCount: 0, rejectedCount: 0, totalRequested: 0, totalApproved: 0, byCategoryData: [], byStatusData: [], monthlyData: [] };
    }

    let approved = 0;
    let rejected = 0;
    let requested = 0;
    let approvedAmount = 0;
    const byCategory: { [key: string]: number } = {};
    const byStatus: { [key: string]: number } = {};

    yearData.forEach(app => {
      if (['Approved', 'Complete', 'Early Report Required', 'Final Report Required', 'Early Report Submitted', 'Final Report Submitted'].includes(app.status)) {
        approved++;
      }
      if (app.status === 'Rejected') {
        rejected++;
      }
      requested += app.amount_requested;
      if (app.amount_approved) {
        approvedAmount += app.amount_approved;
      }

      const categoryName = grantCategories.find(c => c.id === app.grant_category_id)?.name || 'Unknown';
      byCategory[categoryName] = (byCategory[categoryName] || 0) + 1;
      
      byStatus[app.status] = (byStatus[app.status] || 0) + 1;
    });
    
    const byCategoryChartData = Object.entries(byCategory).map(([name, value]) => ({ name, value }));
    const byStatusChartData = Object.entries(byStatus).map(([name, value]) => ({ name, value }));

    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const monthlyChartData = monthNames.map(name => ({ month: name, 'Applications': 0 }));
    yearData.forEach(app => {
        const monthIndex = new Date(app.submission_timestamp).getMonth();
        monthlyChartData[monthIndex]['Applications']++;
    });

    return {
      totalApplications: yearData.length,
      approvedCount: approved,
      rejectedCount: rejected,
      totalRequested: requested,
      totalApproved: approvedAmount,
      byCategoryData: byCategoryChartData,
      byStatusData: byStatusChartData,
      monthlyData: monthlyChartData,
    };
  }, [yearData, grantCategories]);
  
  const chartColors = useMemo(() => {
    const isDark = theme === 'dark';
    return {
      pieFill1: isDark ? '#eed374' : '#004925',
      pieFill2: isDark ? '#D1D5DB' : '#9CA3AF',
      pieFill3: isDark ? '#C8A03E' : '#047857',
      pieFill4: isDark ? '#a0aec0' : '#6b7280',
      pieFill5: isDark ? '#718096' : '#4b5563',
      axisStroke: isDark ? '#A0A0A0' : '#566573',
      gridStroke: isDark ? '#333333' : '#DEE2E6',
      tooltipBg: isDark ? '#252525' : '#FFFFFF',
      tooltipBorder: isDark ? '#333333' : '#DEE2E6',
      tooltipColor: isDark ? '#F9FAFB' : '#2C3E50',
      barFill: isDark ? '#D1D5DB' : '#004925',
      legendColor: isDark ? '#A0A0A0' : '#566573',
    };
  }, [theme]);
  
  const pieColors = [chartColors.pieFill1, chartColors.pieFill2, chartColors.pieFill3, chartColors.pieFill4, chartColors.pieFill5];
  const chartTextStyle = { fill: chartColors.axisStroke, fontSize: 12 };

  if (isLoadingGrantApplications) {
      return <div className="flex justify-center items-center h-full"><Spinner className="w-12 h-12" /><span className="ml-4 text-xl">Loading Grant Analytics...</span></div>;
  }
  
  if (grantApplications.length === 0) {
      return (
          <Card>
              <p className="text-center text-brand-text-secondary-light dark:text-brand-text-secondary py-8">
                  No grant application data is available to generate analytics.
              </p>
          </Card>
      );
  }

  const formatCurrency = (value: number) => `RM ${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  return (
    <div className="space-y-6">
      <Card>
        <div className="flex items-center gap-4">
            <label htmlFor="grant-year-filter" className="text-sm font-medium">Filter by Year:</label>
            <Select id="grant-year-filter" options={yearOptions} value={String(selectedYear)} onChange={e => setSelectedYear(Number(e.target.value))} className="w-32" />
        </div>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title={`Total Applications (${selectedYear})`} value={totalApplications.toLocaleString()} icon={<GrantApplicationsIcon className="w-6 h-6"/>} />
          <StatCard title="Approved Grants" value={approvedCount.toLocaleString()} icon={<CheckCircleIcon className="w-6 h-6"/>} />
          <StatCard title="Rejected Grants" value={rejectedCount.toLocaleString()} icon={<XCircleIcon className="w-6 h-6"/>} />
          <StatCard title="Pending/In-Progress" value={(totalApplications - approvedCount - rejectedCount).toLocaleString()} icon={<GrantApplicationsIcon className="w-6 h-6"/>} />
      </div>
      
       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="Total Amount Requested">
                <p className="text-4xl font-bold text-brand-green-text dark:text-brand-dark-green-text mt-1">{formatCurrency(totalRequested)}</p>
            </Card>
            <Card title="Total Amount Approved">
                <p className="text-4xl font-bold text-green-500 dark:text-green-400 mt-1">{formatCurrency(totalApproved)}</p>
            </Card>
        </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Applications by Category">
            <div style={{ width: '100%', height: 300 }}>
                <ResponsiveContainer>
                    <PieChart>
                        <Pie data={byCategoryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                            {byCategoryData.map((entry, index) => (<Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: chartColors.tooltipBg, border: `1px solid ${chartColors.tooltipBorder}`, borderRadius: '0.5rem' }}/>
                        <Legend wrapperStyle={{ color: chartColors.legendColor }} />
                    </PieChart>
                </ResponsiveContainer>
            </div>
        </Card>
         <Card title="Applications by Status">
            <div style={{ width: '100%', height: 300 }}>
                <ResponsiveContainer>
                    <PieChart>
                        <Pie data={byStatusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                            {byStatusData.map((entry, index) => (<Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: chartColors.tooltipBg, border: `1px solid ${chartColors.tooltipBorder}`, borderRadius: '0.5rem' }}/>
                        <Legend wrapperStyle={{ color: chartColors.legendColor }} />
                    </PieChart>
                </ResponsiveContainer>
            </div>
        </Card>
      </div>

      <Card title={`Monthly Application Submissions for ${selectedYear}`}>
        <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
                <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={chartColors.gridStroke} />
                    <XAxis dataKey="month" stroke={chartColors.axisStroke} tick={chartTextStyle} />
                    <YAxis stroke={chartColors.axisStroke} tick={chartTextStyle} allowDecimals={false} />
                    <Tooltip
                        contentStyle={{ backgroundColor: chartColors.tooltipBg, border: `1px solid ${chartColors.tooltipBorder}`, borderRadius: '0.5rem' }}
                        cursor={{ fill: theme === 'dark' ? '#333333' : '#E9ECEF' }}
                    />
                    <Bar dataKey="Applications" fill={chartColors.barFill} />
                </BarChart>
            </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
};

export default React.memo(GrantAnalyticsView);
