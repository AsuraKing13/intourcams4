import React, { useState } from 'react';
import VisitorAnalyticsView from './VisitorAnalyticsView.tsx';
import EventAnalyticsView from './EventAnalyticsView.tsx';
import ROIStatisticsView from './ROIStatisticsView.tsx';
import ClusterAnalyticsView from './ClusterAnalyticsView.tsx'; // Import the new view
import GrantAnalyticsView from './GrantAnalyticsView.tsx';
import { useAppContext } from '../AppContext.tsx';
import { LockClosedIcon } from '@heroicons/react/24/solid';
import { SparklesIcon } from '../../constants.tsx';
import Card from '../ui/Card.tsx';
import Button from '../ui/Button.tsx';
import AITourismPredictionView from './AITourismPredictionView.tsx';

type AnalyticsTab = 'visitor' | 'event' | 'grant' | 'cluster' | 'roi' | 'ai';

const TourismStatisticsView: React.FC = () => {
    const { isPremiumUser } = useAppContext();
    const [activeTab, setActiveTab] = useState<AnalyticsTab>('visitor');

    const handleTabClick = (tabName: AnalyticsTab) => {
        // Prevent clicking locked tabs
        if ((tabName === 'roi' || tabName === 'cluster' || tabName === 'grant' || tabName === 'ai') && !isPremiumUser) {
            return;
        }
        setActiveTab(tabName);
    };

    const renderActiveTabContent = () => {
        if (activeTab === 'visitor') return <VisitorAnalyticsView />;
        if (activeTab === 'event') return <EventAnalyticsView />;

        // All other tabs are premium
        if (!isPremiumUser) {
            return (
                <Card title="Premium Feature">
                    <div className="text-center py-12">
                        <LockClosedIcon className="mx-auto h-12 w-12 text-neutral-400 dark:text-neutral-500" />
                        <h3 className="mt-2 text-lg font-semibold text-brand-text-light dark:text-brand-text">Access Advanced Analytics</h3>
                        <p className="mt-1 text-brand-text-secondary-light dark:text-brand-text-secondary">
                            Upgrade to a Premium account to unlock detailed Grant, Trends, and ROI analytics.
                        </p>
                        <Button className="mt-4" variant="primary">Upgrade to Premium</Button>
                    </div>
                </Card>
            );
        }
        
        // Render premium tabs
        switch(activeTab) {
            case 'grant': return <GrantAnalyticsView />;
            case 'cluster': return <ClusterAnalyticsView />;
            case 'roi': return <ROIStatisticsView />;
            case 'ai': return <AITourismPredictionView />;
            default: return null;
        }
    };

    const getTabClass = (tabName: AnalyticsTab) => {
        const baseClasses = 'px-4 py-2 font-semibold rounded-t-lg transition-colors focus:outline-none flex items-center gap-2 text-sm sm:text-base whitespace-nowrap';
        if (activeTab === tabName) {
            return `${baseClasses} bg-card-bg-light dark:bg-card-bg text-brand-green-text dark:text-brand-dark-green-text`;
        }
        if ((tabName === 'roi' || tabName === 'cluster' || tabName === 'grant' || tabName === 'ai') && !isPremiumUser) {
            return `${baseClasses} text-neutral-400 dark:text-neutral-500 cursor-not-allowed`;
        }
        return `${baseClasses} text-brand-text-secondary-light dark:text-brand-text-secondary hover:bg-neutral-200-light dark:hover:bg-neutral-800-dark`;
    };

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold text-brand-text-light dark:text-brand-text mb-1">Tourism Statistics</h2>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary">
                    A consolidated view of Sarawak's tourism performance metrics.
                </p>
            </div>

            <div className="border-b border-neutral-300-light dark:border-neutral-700-dark">
                <nav className="-mb-px flex space-x-1 sm:space-x-2 overflow-x-auto custom-scrollbar" aria-label="Tabs">
                    <button onClick={() => handleTabClick('visitor')} className={getTabClass('visitor')}>
                        Visitor Analytics
                    </button>
                    <button onClick={() => handleTabClick('event')} className={getTabClass('event')}>
                        Event Analytics
                    </button>
                    <button onClick={() => handleTabClick('grant')} className={getTabClass('grant')} disabled={!isPremiumUser && activeTab !== 'grant'}>
                        Grant Analytics
                        {!isPremiumUser && <LockClosedIcon className="w-4 h-4 text-yellow-500" />}
                    </button>
                    <button onClick={() => handleTabClick('cluster')} className={getTabClass('cluster')} disabled={!isPremiumUser && activeTab !== 'cluster'}>
                        Trends Analytics
                        {!isPremiumUser && <LockClosedIcon className="w-4 h-4 text-yellow-500" />}
                    </button>
                    <button onClick={() => handleTabClick('roi')} className={getTabClass('roi')} disabled={!isPremiumUser && activeTab !== 'roi'}>
                        ROI Statistics
                        {!isPremiumUser && <LockClosedIcon className="w-4 h-4 text-yellow-500" />}
                    </button>
                    <button onClick={() => handleTabClick('ai')} className={getTabClass('ai')} disabled={!isPremiumUser && activeTab !== 'ai'}>
                        <SparklesIcon className="w-4 h-4 text-yellow-500" /> AI Prediction
                        {!isPremiumUser && <LockClosedIcon className="w-4 h-4 text-yellow-500" />}
                    </button>
                </nav>
            </div>

            <div className="animate-modalShow">
                {renderActiveTabContent()}
            </div>
        </div>
    );
};

export default TourismStatisticsView;
