import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { useAppContext } from '../AppContext.tsx';
import Card from '../ui/Card.tsx';
import Button from '../ui/Button.tsx';
import Spinner from '../ui/Spinner.tsx';
import { SparklesIcon, ArrowPathIcon as RefreshIcon } from '../../constants.tsx';
import { GoogleGenAI, Type } from "@google/genai";

interface Prediction {
    visitorReceiptsPrediction: number;
    incomeProjection: number;
    topCountries: {
        country: string;
        predictedVisitors: number;
    }[];
    analysis: string;
}

const StatCard: React.FC<{ title: string; value: string; }> = ({ title, value }) => (
    <Card>
        <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-sm">{title}</p>
        <p className="text-3xl font-bold text-brand-green-text dark:text-brand-dark-green-text mt-1">{value}</p>
    </Card>
);

const AITourismPredictionView: React.FC = () => {
    const { visitorAnalyticsData, isLoadingVisitorAnalytics, currentUser, getCachedAiInsight, setCachedAiInsight } = useAppContext();
    const [prediction, setPrediction] = useState<Prediction | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const canManage = useMemo(() => currentUser?.role === 'Admin' || currentUser?.role === 'Editor', [currentUser]);
    const nextYear = new Date().getFullYear() + 1;

    const generatePrediction = useCallback(async (): Promise<Prediction | null> => {
        if (visitorAnalyticsData.length === 0) {
            setError("No historical visitor data available to make a prediction.");
            return null;
        }

        // Summarize data by year
        const yearlySummary = visitorAnalyticsData.reduce((acc, curr) => {
            const year = curr.year;
            if (!acc[year]) {
                acc[year] = { totalVisitors: 0, international: 0, domestic: 0, countries: {} };
            }
            acc[year].totalVisitors += curr.count;
            if (curr.visitor_type === 'International') {
                acc[year].international += curr.count;
                acc[year].countries[curr.country] = (acc[year].countries[curr.country] || 0) + curr.count;
            } else {
                acc[year].domestic += curr.count;
            }
            return acc;
        }, {} as Record<number, { totalVisitors: number, international: number, domestic: number, countries: Record<string, number> }>);

        const summarizedData = Object.entries(yearlySummary).map(([year, data]) => ({
            year: parseInt(year),
            totalVisitors: data.totalVisitors,
            totalInternational: data.international,
            totalDomestic: data.domestic,
            topCountries: Object.entries(data.countries).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([country, count]) => ({ country, count }))
        }));
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `
                You are a senior data analyst for the Sarawak Tourism Board. Your task is to provide a data-driven prediction for Sarawak's tourism sector for the year ${nextYear}.

                Current Context for 2025:
                - The official target for 2025 is 5 million total visitors.
                - As of August 2025, visitor arrivals stand at 3.2 million.

                Historical Data (summarized):
                ${JSON.stringify(summarizedData, null, 2)}

                Based on the historical data and the current 2025 context, generate a forecast for the upcoming year, ${nextYear}. Assume an average tourist spending of RM 3,500 per visitor to project income.

                Your predictions must include:
                1.  Total visitor receipts (total number of visitors) for ${nextYear}.
                2.  Projected tourism income for Sarawak in ${nextYear}, based on the visitor prediction and the provided average spending.
                3.  The top 10 countries most likely to visit Sarawak, with a predicted number of visitors for each.
                4.  A brief professional analysis explaining your reasoning. Consider trends, recent growth, and any patterns observed in the data to justify your forecast.

                Your entire response must be in a valid JSON format according to the provided schema.
            `;

            const responseSchema = {
                type: Type.OBJECT,
                properties: {
                    visitorReceiptsPrediction: { type: Type.NUMBER, description: "The predicted total number of visitors for the next year." },
                    incomeProjection: { type: Type.NUMBER, description: "The projected tourism income in Malaysian Ringgit (RM) for the next year." },
                    topCountries: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                country: { type: Type.STRING },
                                predictedVisitors: { type: Type.NUMBER }
                            },
                            required: ["country", "predictedVisitors"]
                        },
                        description: "An array of the top 10 countries with their predicted visitor counts."
                    },
                    analysis: { type: Type.STRING, description: "A professional analysis explaining the reasoning behind the predictions." }
                },
                required: ["visitorReceiptsPrediction", "incomeProjection", "topCountries", "analysis"]
            };

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: { responseMimeType: "application/json", responseSchema: responseSchema },
            });
            
            return JSON.parse(response.text);

        } catch (err) {
            console.error("AI Prediction Error:", err);
            setError("Sorry, we couldn't generate a prediction at this time. The model may be experiencing issues.");
            return null;
        }
    }, [visitorAnalyticsData, nextYear]);

    const loadPrediction = useCallback(async (forceRefresh = false) => {
        setIsGenerating(true);
        setError(null);
        setPrediction(null);
        
        if (forceRefresh && !canManage) forceRefresh = false;

        const cacheKey = 'general';
        const cachedResult = await getCachedAiInsight('ai_tourism_prediction', cacheKey);
        
        const isCacheStale = !cachedResult || (new Date().getTime() - new Date(cachedResult.data_last_updated_at).getTime()) > 24 * 60 * 60 * 1000; // 24 hours

        if (cachedResult && !forceRefresh && !isCacheStale) {
            setPrediction(JSON.parse(cachedResult.content));
            setIsGenerating(false);
            return;
        }

        if (canManage) {
            const newPrediction = await generatePrediction();
            if (newPrediction) {
                setPrediction(newPrediction);
                await setCachedAiInsight('ai_tourism_prediction', cacheKey, JSON.stringify(newPrediction), new Date().toISOString());
            }
        } else {
            if (cachedResult) {
                setPrediction(JSON.parse(cachedResult.content));
            } else {
                setError("The AI prediction has not been generated yet. An administrator can generate the latest forecast.");
            }
        }
        setIsGenerating(false);
    }, [canManage, getCachedAiInsight, setCachedAiInsight, generatePrediction]);

    useEffect(() => {
        if (!isLoadingVisitorAnalytics) {
            loadPrediction();
        }
    }, [isLoadingVisitorAnalytics, loadPrediction]);

    const formatCurrency = (value: number) => `RM ${(value / 1_000_000_000).toFixed(2)} Billion`;

    return (
        <div className="space-y-6">
            <Card
                title="AI-Powered Tourism Forecast"
                titleIcon={<SparklesIcon className="w-5 h-5" />}
                actions={
                    canManage && (
                        <Button
                            variant="secondary" size="sm" onClick={() => loadPrediction(true)}
                            isLoading={isGenerating} leftIcon={<RefreshIcon className="w-4 h-4" />}
                        >
                            Regenerate Prediction
                        </Button>
                    )
                }
            >
                {isGenerating && (
                    <div className="text-center py-12">
                        <Spinner className="w-12 h-12 mx-auto" />
                        <p className="mt-4 text-lg font-semibold text-brand-text-light dark:text-brand-text">
                            Analyzing historical data and generating forecast...
                        </p>
                    </div>
                )}

                {error && <p className="text-center text-red-500 dark:text-red-400 py-8">{error}</p>}

                {prediction && !isGenerating && (
                    <div className="space-y-6 animate-modalShow">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <StatCard title={`Predicted Visitor Receipts (${nextYear})`} value={`${(prediction.visitorReceiptsPrediction / 1_000_000).toFixed(2)} Million`} />
                            <StatCard title={`Projected Tourism Income (${nextYear})`} value={formatCurrency(prediction.incomeProjection)} />
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <Card title="AI Analysis & Reasoning">
                                <p className="text-sm text-brand-text-light dark:text-brand-text whitespace-pre-wrap leading-relaxed">
                                    {prediction.analysis}
                                </p>
                            </Card>
                            <Card title={`Top 10 Predicted Countries to Visit (${nextYear})`}>
                                <div className="overflow-x-auto custom-scrollbar">
                                    <table className="w-full text-sm text-left">
                                        <thead className="text-xs uppercase bg-neutral-100-light dark:bg-neutral-700-dark text-brand-text-secondary-light dark:text-brand-text-secondary">
                                            <tr>
                                                <th className="px-4 py-2">Rank</th>
                                                <th className="px-4 py-2">Country</th>
                                                <th className="px-4 py-2 text-right">Predicted Visitors</th>
                                            </tr>
                                        </thead>
                                        <tbody className="text-brand-text-light dark:text-brand-text">
                                            {prediction.topCountries.map((item, index) => (
                                                <tr key={item.country} className="border-b border-neutral-200-light dark:border-neutral-700-dark">
                                                    <td className="px-4 py-2 font-medium">{index + 1}</td>
                                                    <td className="px-4 py-2">{item.country}</td>
                                                    <td className="px-4 py-2 text-right font-mono">{item.predictedVisitors.toLocaleString()}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </Card>
                        </div>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default AITourismPredictionView;
