import React, { useContext, useMemo, useState } from 'react';
import Card from '../ui/Card.tsx';
import Button from '../ui/Button.tsx';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ThemeContext } from '../ThemeContext.tsx';
import { useAppContext } from '../AppContext.tsx';
import { EventAnalyticsIcon, CalendarDaysIcon } from '../../constants.tsx';

// A local StatCard component for this view
const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <Card>
        <div className="flex items-center">
            <div className="p-3 bg-neutral-200-light dark:bg-neutral-700-dark rounded-lg mr-4 text-brand-green dark:text-brand-dark-green-text">
                {icon}
            </div>
            <div>
                <p className="text-brand-text-secondary-light dark:text-brand-text-secondary text-sm">{title}</p>
                <p className="text-2xl font-bold text-brand-green-text dark:text-brand-dark-green-text">{value}</p>
            </div>
        </div>
    </Card>
);

/**
 * Generates plausible mock historical data for demonstration purposes.
 * It uses the total site visits count as a basis and simulates daily fluctuations.
 * @param totalVisits The final cumulative count of visits.
 * @param days The number of past days to generate data for.
 * @returns An array of data points with date and visit counts.
 */
const generateMockTrafficData = (totalVisits: number, days: number): { date: string, visits: number }[] => {
    if (days <= 0 || totalVisits <= 0) return [];
    
    const data = [];
    const today = new Date();
    
    // Simulate "today's" visits as a small, random fraction of the average daily visits.
    const avgDaily = totalVisits / Math.max(days, 1);
    const todaysVisits = Math.floor(Math.random() * (avgDaily * 0.5) + (avgDaily * 0.2));
    
    let remainingVisits = totalVisits - todaysVisits;
    
    // Generate data for past days
    for (let i = days - 1; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(today.getDate() - i);
        const dateString = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        
        if (i === 0) { // Today
             data.push({ date: dateString, visits: todaysVisits });
        } else {
            // Distribute remaining visits with some randomness
            const dailyShare = remainingVisits / i;
            const fluctuation = dailyShare * 0.4; // +/- 20%
            const visits = Math.floor(Math.max(0, dailyShare - fluctuation + Math.random() * (fluctuation * 2)));
            
            data.push({ date: dateString, visits });
            remainingVisits -= visits;
        }
    }
    
    // Distribute any leftover visits to the first day to ensure the total matches.
    if (days > 1 && remainingVisits > 0 && data[0]) {
        data[0].visits += remainingVisits;
    }

    return data;
};

const WebsiteTrafficView: React.FC = () => {
    const { theme } = useContext(ThemeContext);
    const { siteVisits } = useAppContext();
    const [period, setPeriod] = useState<'day' | 'week' | 'month' | 'year'>('week');

    const trafficData = useMemo(() => {
        switch (period) {
            case 'day': {
                 const todayData = generateMockTrafficData(siteVisits, 1);
                 return todayData.length > 0 ? [{...todayData[0], date: 'Today'}] : [];
            }
            case 'week':
                return generateMockTrafficData(siteVisits, 7);
            case 'month':
                return generateMockTrafficData(siteVisits, 30);
            case 'year': {
                const yearlyData = generateMockTrafficData(siteVisits, 365);
                // For yearly view, aggregate into months to make it readable
                const monthlyAgg: { [key: string]: number } = {};
                yearlyData.forEach(d => {
                    const month = new Date(d.date + `, ${new Date().getFullYear()}`).toLocaleString('en-US', { month: 'short' });
                    if (!monthlyAgg[month]) monthlyAgg[month] = 0;
                    monthlyAgg[month] += d.visits;
                });
                const monthOrder = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                return monthOrder.map(m => ({ date: m, visits: monthlyAgg[m] || 0 }));
            }
            default:
                return [];
        }
    }, [period, siteVisits]);
    
    const visitsThisPeriod = useMemo(() => {
        return trafficData.reduce((sum, item) => sum + item.visits, 0);
    }, [trafficData]);
    
    const periodLabel = useMemo(() => {
        switch (period) {
            case 'day': return "Today's Visits";
            case 'week': return "Last 7 Days";
            case 'month': return "Last 30 Days";
            case 'year': return "Last 365 Days";
        }
    }, [period]);
    
    const chartColors = useMemo(() => ({
        axisStroke: theme === 'dark' ? '#A0A0A0' : '#566573',
        gridStroke: theme === 'dark' ? '#333333' : '#DEE2E6',
        tooltipBg: theme === 'dark' ? '#252525' : '#FFFFFF',
        tooltipBorder: theme === 'dark' ? '#333333' : '#DEE2E6',
        lineColor: theme === 'dark' ? '#eed374' : '#004925',
    }), [theme]);
    const chartTextStyle = { fill: chartColors.axisStroke, fontSize: 12 };

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-2 flex-wrap">
                <p className="text-sm font-medium">Show data for:</p>
                <Button variant={period === 'day' ? 'primary' : 'secondary'} size="sm" onClick={() => setPeriod('day')}>Today</Button>
                <Button variant={period === 'week' ? 'primary' : 'secondary'} size="sm" onClick={() => setPeriod('week')}>Weekly</Button>
                <Button variant={period === 'month' ? 'primary' : 'secondary'} size="sm" onClick={() => setPeriod('month')}>Monthly</Button>
                <Button variant={period === 'year' ? 'primary' : 'secondary'} size="sm" onClick={() => setPeriod('year')}>Yearly</Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <StatCard title="Total Site Visits (All Time)" value={siteVisits.toLocaleString()} icon={<EventAnalyticsIcon className="w-6 h-6" />} />
                <StatCard title={`Visits (${periodLabel})`} value={visitsThisPeriod.toLocaleString()} icon={<CalendarDaysIcon className="w-6 h-6" />} />
            </div>

            <Card title="Traffic Trend">
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                        <LineChart data={trafficData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke={chartColors.gridStroke} />
                            <XAxis dataKey="date" stroke={chartColors.axisStroke} tick={chartTextStyle} />
                            <YAxis stroke={chartColors.axisStroke} tick={chartTextStyle} />
                            <Tooltip
                                contentStyle={{ backgroundColor: chartColors.tooltipBg, border: `1px solid ${chartColors.tooltipBorder}`, borderRadius: '0.5rem' }}
                                cursor={{ fill: theme === 'dark' ? '#333333' : '#E9ECEF' }}
                            />
                            <Line type="monotone" dataKey="visits" name="Visits" stroke={chartColors.lineColor} strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 6 }} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </Card>
        </div>
    );
};

export default WebsiteTrafficView;
