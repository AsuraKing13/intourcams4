
import React, { useContext, useMemo, useState, useEffect } from 'react';
import { ViewName, NavItemType } from '../types.ts';
import { USER_NAV_ITEMS, ADMIN_EDITOR_NAV_ITEMS, GUEST_NAV_ITEMS, VIEW_ACCESS_RULES, LogoIcon, MoonIcon, SunIcon, LoginIcon, ChevronDoubleLeftIcon, ChevronDoubleRightIcon, ChevronDownIcon } from '../constants.tsx';
import { ThemeContext } from './ThemeContext.tsx';
import Button from './ui/Button.tsx';
import { useAppContext } from './AppContext.tsx'; 

interface SidebarProps {
  currentView: ViewName;
  setCurrentView: (view: ViewName) => void;
  isGuest?: boolean;
  onSwitchToLogin?: () => void;
  isCollapsed: boolean;
  toggleCollapse: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, isGuest = false, onSwitchToLogin, isCollapsed, toggleCollapse }) => {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const { currentUser } = useAppContext(); 
  
  const getActiveParent = (items: NavItemType[]) => {
    for (const item of items) {
        if (item.subItems?.some(sub => sub.name === currentView)) {
            return item.name;
        }
    }
    return null;
  };

  const [openDropdowns, setOpenDropdowns] = useState<Set<string>>(new Set());

  // Effect to automatically open the dropdown containing the active view.
  useEffect(() => {
    const baseNavItems = currentUser?.role === 'Admin' || currentUser?.role === 'Editor' ? ADMIN_EDITOR_NAV_ITEMS : USER_NAV_ITEMS;
    const activeParent = getActiveParent(baseNavItems);
    if (activeParent) {
      setOpenDropdowns(prev => new Set(prev).add(activeParent));
    }
  }, [currentView, currentUser]);

  const toggleDropdown = (name: string) => {
    setOpenDropdowns(prev => {
        const newSet = new Set(prev);
        if (newSet.has(name)) {
            newSet.delete(name);
        } else {
            newSet.add(name);
        }
        return newSet;
    });
  };

  // Memoized calculation of navigation items based on user role and guest status.
  const navItems = useMemo(() => {
    if (isGuest) {
      return GUEST_NAV_ITEMS;
    }
    
    const userRole = currentUser?.role?.trim()?.toLowerCase();
    if (!userRole) return [];

    const baseNavItems = (userRole === 'admin' || userRole === 'editor')
      ? ADMIN_EDITOR_NAV_ITEMS
      : USER_NAV_ITEMS;

    // Filter items based on the user's role. This now handles sub-items correctly.
    const filterItems = (items: NavItemType[]): NavItemType[] => {
        return items.map(item => {
            if (item.subItems) {
                const visibleSubItems = item.subItems.filter(subItem => {
                    const requiredRoles = VIEW_ACCESS_RULES[subItem.name as ViewName];
                    return !requiredRoles || requiredRoles.includes(userRole);
                });

                if (visibleSubItems.length > 0) {
                    return { ...item, subItems: visibleSubItems };
                }
                return null;
            }

            const requiredRoles = VIEW_ACCESS_RULES[item.name as ViewName];
            if (!requiredRoles || requiredRoles.includes(userRole)) {
                return item;
            }
            return null;
        }).filter(Boolean) as NavItemType[];
    };
    
    return filterItems(baseNavItems);
  }, [isGuest, currentUser]);

  return (
    <aside className={`flex flex-col h-full shadow-lg print:hidden bg-sidebar-bg-light dark:bg-sidebar-bg text-brand-text-secondary-light dark:text-brand-text-secondary transition-all duration-300 ${isCollapsed ? 'w-20' : 'w-72'}`}>
      <div className={`p-6 border-b border-neutral-300-light dark:border-neutral-700-dark flex flex-col items-center text-center ${isCollapsed ? 'px-2' : ''}`}>
        <LogoIcon className={`w-auto transition-all duration-300 ${isCollapsed ? 'h-12' : 'h-20'}`}/>
        {!isCollapsed && (
          <>
            <h2 className="mt-3 text-lg font-bold text-brand-green-text dark:text-brand-dark-green-text">INTOURCAMS</h2>
            <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">
                Integrated Tourism Coordination and Monitoring System
            </p>
          </>
        )}
      </div>
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
        {navItems.map((item: NavItemType) => {
          if (item.subItems) {
            const isActive = item.subItems.some(sub => sub.name === currentView);
            const isOpen = openDropdowns.has(item.name);
            return (
              <React.Fragment key={item.name}>
                <button
                  onClick={() => toggleDropdown(item.name)}
                  title={item.name}
                  className={`w-full flex items-center justify-between space-x-3 rounded-lg transition-all duration-200 ease-in-out ${isCollapsed ? 'justify-center h-12' : 'px-4 py-3'}
                              ${isActive 
                                  ? 'bg-brand-green dark:bg-brand-dark-green text-white dark:text-white font-semibold shadow-md' 
                                  : 'hover:bg-neutral-200-light dark:hover:bg-neutral-700-dark hover:text-brand-green-text dark:hover:text-brand-dark-green-text'
                              }`}
                  aria-haspopup="true"
                  aria-expanded={isOpen}
                >
                  <div className="flex items-center space-x-3">
                    <item.icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-white' : 'text-brand-green dark:text-brand-dark-green-text'}`} />
                    {!isCollapsed && <span className="transition-opacity duration-200">{item.name}</span>}
                  </div>
                  {!isCollapsed && (
                    <ChevronDownIcon className={`w-5 h-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  )}
                </button>
                {!isCollapsed && isOpen && (
                  <div className="pl-4 space-y-1 mt-1">
                    {item.subItems.map(subItem => (
                       <button
                          key={subItem.name}
                          onClick={() => setCurrentView(subItem.name)}
                          title={subItem.name}
                          className={`w-full flex items-center space-x-3 rounded-lg transition-all duration-200 ease-in-out px-4 py-2
                                      ${currentView === subItem.name 
                                          ? 'bg-brand-green/80 dark:bg-brand-dark-green/80 text-white font-semibold' 
                                          : 'hover:bg-neutral-200-light dark:hover:bg-neutral-700-dark'
                                      }`}
                          aria-current={currentView === subItem.name ? "page" : undefined}
                          aria-label={subItem.name}
                        >
                          <subItem.icon className="w-5 h-5 flex-shrink-0" />
                          <span>{subItem.name}</span>
                        </button>
                    ))}
                  </div>
                )}
              </React.Fragment>
            );
          }

          return (
            <button
              key={item.name}
              onClick={() => setCurrentView(item.name as ViewName)}
              title={item.name}
              className={`w-full flex items-center space-x-3 rounded-lg transition-all duration-200 ease-in-out ${isCollapsed ? 'justify-center h-12' : 'px-4 py-3'}
                          ${currentView === item.name 
                              ? 'bg-brand-green dark:bg-brand-dark-green text-white dark:text-white font-semibold shadow-md' 
                              : 'hover:bg-neutral-200-light dark:hover:bg-neutral-700-dark hover:text-brand-green-text dark:hover:text-brand-dark-green-text'
                          }`}
              aria-current={currentView === item.name ? "page" : undefined}
              aria-label={item.name}
            >
              <item.icon className={`w-5 h-5 flex-shrink-0 ${currentView === item.name ? 'text-white' : 'text-brand-green dark:text-brand-dark-green-text'}`} />
              {!isCollapsed && <span className="transition-opacity duration-200">{item.name}</span>}
            </button>
          );
        })}
      </nav>
      <div className={`p-4 border-t border-neutral-300-light dark:border-neutral-700-dark ${isCollapsed ? 'px-2' : ''}`}>
        {isGuest && onSwitchToLogin && !isCollapsed && (
            <div className='mb-4'>
                <Button 
                    variant="primary" 
                    size="md" 
                    onClick={onSwitchToLogin} 
                    leftIcon={<LoginIcon className="w-5 h-5"/>}
                    className="w-full"
                    title="Admin & User Login"
                >
                    Admin & User Login
                </Button>
            </div>
        )}
        <div className="flex flex-col space-y-2">
            <button
              onClick={toggleTheme}
              className="w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg bg-neutral-200-light dark:bg-neutral-700-dark hover:bg-neutral-300-light dark:hover:bg-neutral-600-dark text-brand-text-secondary-light dark:text-brand-text-secondary transition-colors"
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
              title={isCollapsed ? (theme === 'dark' ? 'Light Mode' : 'Dark Mode') : `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            >
              {theme === 'dark' ? <SunIcon className="w-5 h-5 text-yellow-400" /> : <MoonIcon className="w-5 h-5 text-indigo-400" />}
              {!isCollapsed && <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>}
            </button>
             <button
              onClick={toggleCollapse}
              className="w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg bg-neutral-200-light dark:bg-neutral-700-dark hover:bg-neutral-300-light dark:hover:bg-neutral-600-dark text-brand-text-secondary-light dark:text-brand-text-secondary transition-colors"
              aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              {isCollapsed ? <ChevronDoubleRightIcon className="w-5 h-5 text-brand-green dark:text-brand-dark-green-text" /> : <ChevronDoubleLeftIcon className="w-5 h-5 text-brand-green dark:text-brand-dark-green-text" />}
              {!isCollapsed && <span>Collapse Menu</span>}
            </button>
        </div>
        {!isCollapsed && (
            <p className="text-xs text-center mt-4 text-neutral-500-light dark:text-neutral-500-dark">
              © {new Date().getFullYear()} All rights reserved.
            </p>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
