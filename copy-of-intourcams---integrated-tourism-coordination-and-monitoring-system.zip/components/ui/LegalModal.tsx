import React from 'react';
import Modal from './Modal.tsx';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  lastUpdated: string;
  children: React.ReactNode;
}

const LegalModal: React.FC<LegalModalProps> = ({ isOpen, onClose, title, lastUpdated, children }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} size="2xl">
      <div className="space-y-4 text-brand-text-light dark:text-brand-text">
        <p className="text-xs text-brand-text-secondary-light dark:text-brand-text-secondary">
          Last updated on {lastUpdated}
        </p>
        {/* Using a div with custom styles for better control over text appearance */}
        <div className="space-y-3 text-sm leading-relaxed">
          {children}
        </div>
      </div>
    </Modal>
  );
};

// --- Content Components for Modals ---

export const PrivacyPolicyContent: React.FC = () => (
    <>
      <h4 className="font-semibold text-base">1. Introduction</h4>
      <p>Welcome to INTOURCAMS ("we", "our", "us"). We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform. By using INTOURCAMS, you agree to the collection and use of information in accordance with this policy.</p>
      
      <h4 className="font-semibold text-base">2. Information We Collect</h4>
      <p>We may collect information about you in a variety of ways. The information we may collect on the platform includes:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li><strong>Personal Data:</strong> Personally identifiable information, such as your name, email address, and contact number, that you voluntarily give to us when you register with the platform or when you choose to participate in various activities related to the platform, such as submitting grant applications or feedback.</li>
        <li><strong>User-Generated Content:</strong> Information you provide when you create or manage tourism clusters, submit grant applications, post reviews, or submit feedback. This includes text, images, and other data you upload.</li>
        <li><strong>Usage Data:</strong> Information our servers automatically collect when you access the platform, such as your IP address, your browser type, your operating system, your access times, and the pages you have viewed directly before and after accessing the platform.</li>
      </ul>

      <h4 className="font-semibold text-base">3. How We Use Your Information</h4>
      <p>Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the platform to:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li>Create and manage your account.</li>
        <li>Process your grant applications and track their status.</li>
        <li>Display your user-generated content, such as cluster information and reviews.</li>
        <li>Monitor and analyze usage and trends to improve your experience with the platform.</li>
        <li>Generate anonymized, aggregated statistical data for tourism analysis and reporting by the Sarawak government and associated bodies.</li>
        <li>Respond to your feedback and support requests.</li>
      </ul>

      <h4 className="font-semibold text-base">4. Disclosure of Your Information</h4>
      <p>We do not share your personal information with third parties except in the circumstances described below:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li><strong>By Law or to Protect Rights:</strong> If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation.</li>
        <li><strong>Aggregated Data:</strong> We may share aggregated and anonymized information with government partners for tourism planning and statistical analysis. This information does not contain any personal data.</li>
        <li><strong>Service Providers:</strong> We may share your information with third-party vendors, service contractors, or agents who perform services for us or on our behalf, such as data storage and hosting.</li>
      </ul>

      <h4 className="font-semibold text-base">5. Security of Your Information</h4>
      <p>We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.</p>

      <h4 className="font-semibold text-base">6. Your Rights</h4>
      <p>You have the right to review, change, or terminate your account at any time. You can review or change the information in your account or terminate your account by logging into your account settings and updating your account, or by contacting us using the contact information provided below.</p>

      <h4 className="font-semibold text-base">7. Changes to This Privacy Policy</h4>
      <p>We may update this Privacy Policy from time to time in order to reflect, for example, changes to our practices or for other operational, legal, or regulatory reasons. We will notify you of any changes by posting the new Privacy Policy on this page.</p>

      <h4 className="font-semibold text-base">8. Contact Us</h4>
      <p>If you have questions or comments about this Privacy Policy, please contact us at: intourcams@gmail.com</p>
    </>
);

export const TermsAndConditionsContent: React.FC = () => (
    <>
      <h4 className="font-semibold text-base">1. Acceptance of Terms</h4>
      <p>By accessing and using the Integrated Tourism Coordination and Monitoring System (INTOURCAMS), you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by these terms, please do not use this service.</p>

      <h4 className="font-semibold text-base">2. User Accounts and Responsibilities</h4>
      <p>To access certain features, you must register for an account. You agree to:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li>Provide true, accurate, current, and complete information about yourself as prompted by the registration form.</li>
        <li>Maintain the security of your password and identification.</li>
        <li>Be fully responsible for all use of your account and for any actions that take place using your account.</li>
      </ul>

      <h4 className="font-semibold text-base">3. User Conduct and Content</h4>
      <p>You are solely responsible for all data, text, images, or other materials ("Content") that you upload, post, or otherwise transmit via the platform. You agree not to use the service to:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li>Upload any Content that is unlawful, harmful, threatening, abusive, defamatory, obscene, or otherwise objectionable.</li>
        <li>Impersonate any person or entity or falsely state or otherwise misrepresent your affiliation with a person or entity.</li>
        <li>Upload any Content that you do not have a right to transmit under any law or under contractual or fiduciary relationships.</li>
      </ul>
      <p>We reserve the right, but have no obligation, to monitor and remove any Content that we deem, in our sole discretion, to violate these terms.</p>

      <h4 className="font-semibold text-base">4. Intellectual Property</h4>
      <p>The platform and its original content, features, and functionality are and will remain the exclusive property of INTOURCAMS and its licensors. By submitting Content to the platform, you grant us a worldwide, non-exclusive, royalty-free license to use, reproduce, modify, and display such Content in connection with operating and providing the service.</p>

      <h4 className="font-semibold text-base">5. Disclaimers</h4>
      <p>The service is provided on an "AS IS" and "AS AVAILABLE" basis. We make no warranties, expressed or implied, regarding the accuracy, reliability, or completeness of the content provided by users on the platform. Your use of the service is at your sole risk.</p>

      <h4 className="font-semibold text-base">6. Limitation of Liability</h4>
      <p>In no event shall INTOURCAMS, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the service.</p>

      <h4 className="font-semibold text-base">7. Termination</h4>
      <p>We may terminate or suspend your account and bar access to the service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of the Terms.</p>

      <h4 className="font-semibold text-base">8. Governing Law</h4>
      <p>These Terms shall be governed and construed in accordance with the laws of Sarawak, Malaysia, without regard to its conflict of law provisions.</p>

      <h4 className="font-semibold text-base">9. Changes to Terms</h4>
      <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms & Conditions on this page.</p>

      <h4 className="font-semibold text-base">10. Contact Us</h4>
      <p>If you have any questions about these Terms, please contact us at: intourcams@gmail.com</p>
    </>
);

export const AccessibilityContent: React.FC = () => (
    <>
      <h4 className="font-semibold text-base">1. Our Commitment</h4>
      <p>INTOURCAMS is committed to ensuring digital accessibility for people with disabilities. We are continually improving the user experience for everyone and applying the relevant accessibility standards, such as the Web Content Accessibility Guidelines (WCAG) 2.1.</p>
    
      <h4 className="font-semibold text-base">2. Measures We Have Taken</h4>
      <p>We have implemented the following features to make our platform more accessible:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li><strong>Font Size Adjustment:</strong> Users can increase the font size across the application for better readability through the accessibility menu in the header.</li>
        <li><strong>High-Contrast Mode:</strong> A high-contrast mode is available to ensure text is easily distinguishable from the background. This can be activated from the accessibility menu.</li>
        <li><strong>Keyboard Navigation:</strong> All interactive elements of the application are reachable and operable using a keyboard. We have also implemented enhanced visual focus indicators to make keyboard navigation clearer.</li>
        <li><strong>Semantic HTML and ARIA:</strong> We use semantic HTML5 and ARIA (Accessible Rich Internet Applications) attributes where appropriate to improve navigation and understanding for users of screen readers and other assistive technologies.</li>
        <li><strong>Responsive Design:</strong> The platform is designed to be responsive and usable across a wide range of screen sizes and devices, from desktops to mobile phones.</li>
      </ul>

      <h4 className="font-semibold text-base">3. Ongoing Efforts</h4>
      <p>We understand that accessibility is an ongoing effort. We are continuously seeking out solutions that will bring all areas of the site up to the same level of overall web accessibility. We regularly review our site to identify and fix any accessibility issues.</p>
      
      <h4 className="font-semibold text-base">4. Feedback</h4>
      <p>We welcome your feedback on the accessibility of INTOURCAMS. If you encounter accessibility barriers or have suggestions on how we can improve, please let us know:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li><strong>Email:</strong> intourcams@gmail.com</li>
        <li>You can also submit feedback directly through the "System Feedback" section in your Profile Settings.</li>
      </ul>
      <p>We try to respond to feedback within 5 business days.</p>
    </>
);

export default LegalModal;