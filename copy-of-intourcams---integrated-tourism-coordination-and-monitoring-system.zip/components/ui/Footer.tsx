import React, { useState } from 'react';
import { LogoIcon } from '../../constants.tsx';
import { useAppContext } from '../AppContext.tsx';
import LegalModal, { PrivacyPolicyContent, TermsAndConditionsContent, AccessibilityContent } from './LegalModal.tsx';
import PublicFeedbackModal from './PublicFeedbackModal.tsx';

type ModalType = 'privacy' | 'terms' | 'accessibility';

const Footer: React.FC = () => {
    const { siteVisits } = useAppContext();
    const [activeModal, setActiveModal] = useState<ModalType | null>(null);
    const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);

    const footerSections = [
        {
            title: 'About Us',
            links: [
                { name: 'Our Mission', href: 'https://mukah.sarawak.gov.my/web/subpage/webpage_view/351' },
                { name: 'Contact Us', href: 'https://mukah.sarawak.gov.my/web/subpage/staffcontact_view/81' },
            ],
        },
        {
            title: 'Legal',
            links: [
                { name: 'Privacy Policy', action: () => setActiveModal('privacy') },
                { name: 'Terms & Conditions', action: () => setActiveModal('terms') },
                { name: 'Accessibility', action: () => setActiveModal('accessibility') },
            ],
        },
    ];
    
    const modalContent = {
        privacy: { title: 'Privacy Policy', date: '10/08/2025', content: <PrivacyPolicyContent /> },
        terms: { title: 'Terms & Conditions', date: '10/08/2025', content: <TermsAndConditionsContent /> },
        accessibility: { title: 'Accessibility Statement', date: '10/08/2025', content: <AccessibilityContent /> },
    };

    const currentModal = activeModal ? modalContent[activeModal] : null;

    return (
        <>
            <footer className="bg-sidebar-bg-light dark:bg-sidebar-bg text-brand-text-secondary-light dark:text-brand-text-secondary border-t border-neutral-300-light dark:border-neutral-700-dark print:hidden">
                <div className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {/* Logo and Title */}
                        <div className="space-y-4 md:col-span-2 lg:col-span-1">
                            <LogoIcon className="h-16 w-auto" />
                            <p className="text-sm leading-6">
                                Integrated Tourism Coordination and Monitoring System.
                            </p>
                        </div>

                        {/* Links */}
                        <div className="grid grid-cols-2 gap-8 lg:col-span-2">
                            {footerSections.map((section) => (
                                <div key={section.title}>
                                    <h3 className="text-sm font-semibold leading-6 text-brand-text-light dark:text-brand-text">
                                        {section.title}
                                    </h3>
                                    <ul role="list" className="mt-4 space-y-2">
                                        {section.links.map((item) => (
                                            <li key={item.name}>
                                                {item.href ? (
                                                     <a href={item.href} target="_blank" rel="noopener noreferrer" className="text-sm leading-6 hover:text-brand-green dark:hover:text-brand-dark-green-text">
                                                        {item.name}
                                                    </a>
                                                ) : (
                                                    <button onClick={item.action} className="text-sm leading-6 hover:text-brand-green dark:hover:text-brand-dark-green-text text-left">
                                                        {item.name}
                                                    </button>
                                                )}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            ))}
                        </div>

                        {/* Contact Info */}
                        <div>
                             <h3 className="text-sm font-semibold leading-6 text-brand-text-light dark:text-brand-text">
                                Contact
                            </h3>
                            <div className="mt-4 space-y-2 text-sm">
                                <p>Level 10, Menara Pehin Setia Raja<br />96400 Mukah<br />Sarawak</p>
                                <p>
                                    <strong>Email:</strong><br />
                                    <button onClick={() => setIsFeedbackModalOpen(true)} className="hover:text-brand-green dark:hover:text-brand-dark-green-text text-left">
                                        intourcams@gmail.com
                                    </button>
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Bottom Bar */}
                    <div className="mt-12 border-t border-neutral-300-light dark:border-neutral-700-dark pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
                        <p className="text-xs leading-5 text-center sm:text-left">
                            &copy; 2025 Integrated Tourism Coordination and Monitoring System. All rights reserved.
                        </p>
                        <div className="text-xs">
                            Total Site Visits: <span className="font-semibold text-brand-text-light dark:text-brand-text">{siteVisits > 0 ? siteVisits.toLocaleString() : '...'}</span>
                        </div>
                    </div>
                </div>
            </footer>
            
            {currentModal && (
                <LegalModal
                    isOpen={!!activeModal}
                    onClose={() => setActiveModal(null)}
                    title={currentModal.title}
                    lastUpdated={currentModal.date}
                >
                    {currentModal.content}
                </LegalModal>
            )}

            <PublicFeedbackModal 
                isOpen={isFeedbackModalOpen} 
                onClose={() => setIsFeedbackModalOpen(false)} 
            />
        </>
    );
};

export default Footer;