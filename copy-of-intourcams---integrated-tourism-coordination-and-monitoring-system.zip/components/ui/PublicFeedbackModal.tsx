import React, { useState } from 'react';
import Modal from './Modal.tsx';
import Button from './Button.tsx';
import { useAppContext } from '../AppContext.tsx';
import { useToast } from '../ToastContext.tsx';

interface PublicFeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PublicFeedbackModal: React.FC<PublicFeedbackModalProps> = ({ isOpen, onClose }) => {
    const { addFeedback, currentUser } = useAppContext();
    const { showToast } = useToast();
    const [content, setContent] = useState('');
    const [isAnonymous, setIsAnonymous] = useState(!currentUser); // Default to true if guest
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!content.trim()) {
            showToast("Feedback cannot be empty.", "error");
            return;
        }
        setIsSubmitting(true);
        try {
            await addFeedback(content, isAnonymous, 'Footer Contact Form');
            showToast("Thank you! Your feedback has been submitted.", "success");
            setContent('');
            onClose(); // Close modal on success
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleClose = () => {
        // Reset state on close
        setContent('');
        setIsAnonymous(!currentUser);
        onClose();
    }

    return (
        <Modal isOpen={isOpen} onClose={handleClose} title="Submit Feedback">
            <form onSubmit={handleSubmit} className="space-y-4">
                <p className="text-sm text-brand-text-secondary-light dark:text-brand-text-secondary">
                    Have a question or suggestion? We'd love to hear from you. Fill out the form below to send us a message.
                </p>
                <div>
                    <label htmlFor="feedback-content-public" className="block text-sm font-medium text-brand-text-secondary-light dark:text-brand-text-secondary mb-1">
                        Your Message
                    </label>
                    <textarea
                        id="feedback-content-public"
                        rows={6}
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        className="w-full rounded-lg p-2.5 outline-none transition-colors bg-input-bg-light dark:bg-input-bg border border-neutral-300-light dark:border-neutral-600-dark text-brand-text-light dark:text-brand-text focus:ring-brand-green dark:focus:ring-brand-dark-green focus:border-brand-green dark:focus:border-brand-dark-green"
                        placeholder="Describe your experience, suggestions, or any issues you've encountered..."
                        required
                        disabled={isSubmitting}
                    />
                </div>
                {currentUser && (
                    <div className="flex items-center">
                        <input
                            id="anonymous-checkbox-public"
                            type="checkbox"
                            checked={isAnonymous}
                            onChange={(e) => setIsAnonymous(e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-brand-green focus:ring-brand-green"
                            disabled={isSubmitting}
                        />
                        <label htmlFor="anonymous-checkbox-public" className="ml-2 block text-sm text-brand-text-light dark:text-brand-text">
                            Submit Anonymously
                        </label>
                    </div>
                )}
                <div className="flex justify-end space-x-3 pt-4 border-t border-neutral-200-light dark:border-neutral-700-dark">
                    <Button type="button" variant="secondary" onClick={handleClose} disabled={isSubmitting}>Cancel</Button>
                    <Button type="submit" variant="primary" isLoading={isSubmitting}>
                        Send Message
                    </Button>
                </div>
            </form>
        </Modal>
    );
};

export default PublicFeedbackModal;